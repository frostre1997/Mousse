package com.geode.mouse_on_android;

import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;

/**
 * Java-side bridge that captures Android mouse/trackpad input events
 * and forwards them to the native C++ mod via JNI.
 *
 * This class is instantiated and attached to the GeometryDash activity
 * via Geode's Android hook system.
 */
public class MouseBridge {

    private static boolean hasPointerDevice = false;
    private static float lastX = 0f;
    private static float lastY = 0f;
    private static boolean initialized = false;

    /**
     * Call this from the Activity's onTouchEvent or onGenericMotionEvent
     * when a source with SOURCE_MOUSE or SOURCE_MOUSE_RELATIVE is detected.
     *
     * @param event The MotionEvent from the activity
     * @return true if the event was handled by the mouse bridge
     */
    public static boolean handleMotionEvent(MotionEvent event) {
        int source = event.getSource();

        // Only handle mouse/trackpad sources
        boolean isMouse = (source & InputDevice.SOURCE_MOUSE) == InputDevice.SOURCE_MOUSE
                       || (source & InputDevice.SOURCE_MOUSE_RELATIVE) == InputDevice.SOURCE_MOUSE_RELATIVE
                       || (source & InputDevice.SOURCE_TRACKBALL) == InputDevice.SOURCE_TRACKBALL;

        if (!isMouse) {
            return false;
        }

        if (!hasPointerDevice) {
            hasPointerDevice = true;
            nativeOnPointerConnect();
        }

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_HOVER_MOVE: {
                // Relative motion for mouse
                float dx = event.getX() - lastX;
                float dy = event.getY() - lastY;
                lastX = event.getX();
                lastY = event.getY();
                nativeOnMouseMove(dx, dy);
                return true;
            }

            case MotionEvent.ACTION_BUTTON_PRESS: {
                int button = event.getActionButton();
                int mappedButton = mapAndroidButton(button);
                nativeOnMouseButton(mappedButton, true);
                return true;
            }

            case MotionEvent.ACTION_BUTTON_RELEASE: {
                int button = event.getActionButton();
                int mappedButton = mapAndroidButton(button);
                nativeOnMouseButton(mappedButton, false);
                return true;
            }

            case MotionEvent.ACTION_SCROLL: {
                float vScroll = event.getAxisValue(MotionEvent.AXIS_VSCROLL);
                float hScroll = event.getAxisValue(MotionEvent.AXIS_HSCROLL);
                if (vScroll != 0f) {
                    nativeOnMouseScroll(vScroll);
                }
                if (hScroll != 0f) {
                    nativeOnMouseScroll(hScroll);
                }
                return true;
            }

            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_DOWN: {
                // Treat touch-down as left click if no mouse buttons are reported
                nativeOnMouseButton(0, true);
                lastX = event.getX();
                lastY = event.getY();
                return false; // Let GD handle it too
            }

            case MotionEvent.ACTION_POINTER_UP:
            case MotionEvent.ACTION_UP: {
                nativeOnMouseButton(0, false);
                return false;
            }

            case MotionEvent.ACTION_MOVE: {
                if ((source & InputDevice.SOURCE_TOUCHSCREEN) != 0) {
                    // Regular touch — do not intercept
                    return false;
                }
                float dx = event.getX() - lastX;
                float dy = event.getY() - lastY;
                lastX = event.getX();
                lastY = event.getY();
                nativeOnMouseMove(dx, dy);
                return true;
            }
        }

        return false;
    }

    /**
     * Call this when the activity is destroyed or paused
     * to clean up state.
     */
    public static void onPause() {
        if (hasPointerDevice) {
            nativeOnPointerDisconnect();
            hasPointerDevice = false;
        }
    }

    /**
     * Call this when the activity is resumed.
     */
    public static void onResume() {
        // Check if a mouse is still connected
        // (will be re-detected on next motion event)
        hasPointerDevice = false;
    }

    private static int mapAndroidButton(int androidButton) {
        switch (androidButton) {
            case MotionEvent.BUTTON_PRIMARY:
                return 0; // Left
            case MotionEvent.BUTTON_SECONDARY:
                return 1; // Right
            case MotionEvent.BUTTON_TERTIARY:
                return 2; // Middle
            case MotionEvent.BUTTON_BACK:
                return 1; // Map Android back to right-click
            default:
                return 0;
        }
    }

    // ─── Native JNI methods (implemented in src/main.cpp) ─────────────

    private static native void nativeOnMouseMove(float dx, float dy);
    private static native void nativeOnMouseButton(int button, boolean down);
    private static native void nativeOnMouseScroll(float delta);
    private static native void nativeOnPointerConnect();
    private static native void nativeOnPointerDisconnect();
}
