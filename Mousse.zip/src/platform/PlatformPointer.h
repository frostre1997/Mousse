#pragma once

#include <Geode/Geode.hpp>

/**
 * Abstract interface for platform-specific pointer input handling.
 *
 * Different platforms (Android, iOS, etc.) have different APIs
 * for capturing mouse/trackpad input. This interface allows
 * the mod to work across platforms with platform-specific backends.
 */
class PlatformPointer {
public:
    virtual ~PlatformPointer() = default;

    /// Called once when the mod loads
    virtual bool initialize() = 0;

    /// Called every frame to process pending input
    virtual void update() = 0;

    /// Called when the mod is being unloaded
    virtual void shutdown() = 0;

    /// Returns true if a pointer device is currently connected
    virtual bool hasPointerDevice() const = 0;

    /// Create the appropriate platform-specific implementation
    static PlatformPointer* create();
};
