#include "PlatformPointer.h"

#ifdef GEODE_IS_ANDROID
#include "android_pointer.h"
#endif

#include <Geode/Geode.hpp>

using namespace geode::prelude;

/// Android-specific implementation
#ifdef GEODE_IS_ANDROID

class AndroidPlatformPointer : public PlatformPointer {
public:
    bool initialize() override {
        if (!mouse_on_android::initJNIBridge()) {
            log::warn("Failed to initialize Android pointer JNI bridge");
            return false;
        }
        mouse_on_android::attachToActivity();
        log::info("AndroidPlatformPointer initialized");
        return true;
    }

    void update() override {
        // Input processing is handled in the scheduler hook (main.cpp)
        // This is a no-op stub for the interface
    }

    void shutdown() override {
        mouse_on_android::detachFromActivity();
        log::info("AndroidPlatformPointer shut down");
    }

    bool hasPointerDevice() const override {
        return mouse_on_android::isPointerDeviceConnected();
    }
};

#else

/// Stub for unsupported platforms
class StubPlatformPointer : public PlatformPointer {
public:
    bool initialize() override { return false; }
    void update() override {}
    void shutdown() override {}
    bool hasPointerDevice() const override { return false; }
};

#endif

// ─── Factory ────────────────────────────────────────────────────────────────

PlatformPointer* PlatformPointer::create() {
#ifdef GEODE_IS_ANDROID
    return new AndroidPlatformPointer();
#else
    return new StubPlatformPointer();
#endif
}
