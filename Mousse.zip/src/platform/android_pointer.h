#pragma once

#ifdef GEODE_IS_ANDROID

/**
 * Platform-specific header for Android pointer input.
 *
 * This header declares the JNI-based bridge functions that
 * connect Android mouse/trackpad events to the native mod.
 */

#include <jni.h>
#include <Geode/Geode.hpp>

namespace mouse_on_android {

/**
 * Initialize the JNI bridge for mouse input capture.
 * Registers native methods with the MouseBridge Java class.
 *
 * @return true if registration succeeded
 */
bool initJNIBridge();

/**
 * Register the MouseBridge with the current Activity's
 * input event dispatch chain.
 */
void attachToActivity();

/**
 * Detach from the activity (cleanup on mod unload).
 */
void detachFromActivity();

/**
 * Check whether a mouse/trackpad is currently detected
 * as an input device.
 */
bool isPointerDeviceConnected();

} // namespace mouse_on_android

#else

// Stub for non-Android platforms — the mod is Android-only
namespace mouse_on_android {
    inline bool initJNIBridge() { return false; }
    inline void attachToActivity() {}
    inline void detachFromActivity() {}
    inline bool isPointerDeviceConnected() { return false; }
}

#endif // GEODE_IS_ANDROID
