#include "android_pointer.h"

#ifdef GEODE_IS_ANDROID

#include <Geode/Geode.hpp>
#include <cocos2d.h>
#include <jni.h>
#include <android/input.h>

using namespace geode::prelude;

// ─── Forward declarations from main.cpp ─────────────────────────────────────
// These are defined in the $modify class MyCCEGLView
namespace {
    void onPointerMove(float dx, float dy);
    void onPointerButton(int button, bool down);
    void onPointerScroll(float delta);
    void onPointerConnect();
    void onPointerDisconnect();
}

// ─── JNI helpers ────────────────────────────────────────────────────────────

static JNIEnv* getEnv() {
    auto vm = geode::jni::getVM();
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        vm->AttachCurrentThread(&env, nullptr);
    }
    return env;
}

// ─── Native method implementations (called from Java) ───────────────────────

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseMove(
    JNIEnv* env, jclass clazz, jfloat dx, jfloat dy) {
    onPointerMove(static_cast<float>(dx), static_cast<float>(dy));
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseButton(
    JNIEnv* env, jclass clazz, jint button, jboolean down) {
    onPointerButton(static_cast<int>(button), down == JNI_TRUE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseScroll(
    JNIEnv* env, jclass clazz, jfloat delta) {
    onPointerScroll(static_cast<float>(delta));
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerConnect(
    JNIEnv* env, jclass clazz) {
    onPointerConnect();
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerDisconnect(
    JNIEnv* env, jclass clazz) {
    onPointerDisconnect();
}

// ─── Public API implementations ─────────────────────────────────────────────

namespace mouse_on_android {

bool initJNIBridge() {
    auto env = getEnv();
    jclass clazz = env->FindClass("com/geode/mouse_on_android/MouseBridge");
    
    if (!clazz) {
        log::warn("MouseBridge: Java class not found");
        return false;
    }
    
    JNINativeMethod methods[] = {
        {"nativeOnMouseMove",       "(FF)V", reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseMove)},
        {"nativeOnMouseButton",     "(IZ)V", reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseButton)},
        {"nativeOnMouseScroll",     "(F)V",  reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseScroll)},
        {"nativeOnPointerConnect",  "()V",   reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerConnect)},
        {"nativeOnPointerDisconnect","()V",  reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerDisconnect)},
    };
    
    jint result = env->RegisterNatives(clazz, methods, 5);
    env->DeleteLocalRef(clazz);
    
    if (result < 0) {
        log::warn("MouseBridge: Failed to register native methods");
        return false;
    }
    
    log::info("MouseBridge JNI bridge initialized");
    return true;
}

void attachToActivity() {
    // The JNI bridge is initialized; actual event capture
    // is handled by the Java-side MouseBridge.handleMotionEvent()
    // which should be called from the Activity's dispatchTouchEvent.
    log::info("MouseBridge attached — waiting for pointer input");
}

void detachFromActivity() {
    onPointerDisconnect();
    log::info("MouseBridge detached");
}

bool isPointerDeviceConnected() {
    // This is tracked in the C++ side via g_hasPointerDevice
    // but we expose it here for external queries.
    return false; // Actual value accessed via the global in main.cpp
}

} // namespace mouse_on_android

#endif // GEODE_IS_ANDROID
