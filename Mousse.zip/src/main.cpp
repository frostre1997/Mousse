#include <Geode/Geode.hpp>
#include <Geode/modify/CCMouseDispatcher.hpp>
#include <Geode/modify/CCKeyboardDispatcher.hpp>
#include <Geode/modify/CCEGLView.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/MenuLayer.hpp>
#include <Geode/modify/EditorUI.hpp>
#include <Geode/modify/CCScheduler.hpp>
#include <Geode/binding/CCMouseDelegate.hpp>
#include <cocos2d.h>
#include <thread>
#include <mutex>
#include <cmath>

using namespace geode::prelude;

// ─── Helper: Get the mod's setting value ────────────────────────────────────

static inline float getSettingFloat(const char* key, float fallback = 1.f) {
    auto mod = Mod::get();
    if (!mod) return fallback;
    auto val = mod->getSettingValue<double>(key);
    return static_cast<float>(val);
}

static inline bool getSettingBool(const char* key, bool fallback = true) {
    auto mod = Mod::get();
    if (!mod) return fallback;
    return mod->getSettingValue<bool>(key);
}

// ─── Cursor sprite ──────────────────────────────────────────────────────────

class CursorNode : public CCSprite {
protected:
    bool init() override {
        if (!CCSprite::init()) return false;
        
        auto winSize = CCDirector::get()->getWinSize();
        
        // Create a simple white circle cursor
        auto renderTexture = CCRenderTexture::create(32, 32);
        renderTexture->beginWithClear(0, 0, 0, 0);
        
        auto drawNode = CCDrawNode::create();
        drawNode->drawDot({16, 16}, 8, {1, 1, 1, 1});
        drawNode->drawCircle({16, 16}, 8, 0, 360, false, 1, 1, {1, 1, 1, 0.5});
        drawNode->visit();
        
        renderTexture->end();
        
        auto texture = renderTexture->getSprite()->getTexture();
        this->initWithTexture(texture);
        this->setScale(0.75f * getSettingFloat("cursor-size", 1.0f));
        this->setZOrder(999999);
        this->setID("mouse-cursor"_spr);
        
        return true;
    }
    
public:
    static CursorNode* create() {
        auto ret = new CursorNode();
        if (ret && ret->init()) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
    
    void updateScale() {
        this->setScale(0.75f * getSettingFloat("cursor-size", 1.0f));
    }
};

// ─── Pointer state ──────────────────────────────────────────────────────────

struct PointerState {
    float x = 0.f;
    float y = 0.f;
    float rawDx = 0.f;
    float rawDy = 0.f;
    bool leftDown = false;
    bool rightDown = false;
    bool middleDown = false;
    float scrollDelta = 0.f;
    bool hasMoved = false;
};

static std::mutex g_pointerMutex;
static PointerState g_pointer;
static CursorNode* g_cursor = nullptr;
static bool g_cursorVisible = true;
static bool g_hasPointerDevice = false;

// ─── Simulated mouse events ─────────────────────────────────────────────────

enum class SimulatedEventType {
    MouseDown,
    MouseUp,
    MouseMove,
    Scroll
};

struct SimulatedEvent {
    SimulatedEventType type;
    float x, y;
    int button; // 0=left, 1=right, 2=middle
    float scrollY;
};

static std::vector<SimulatedEvent> g_eventQueue;
static std::mutex g_eventMutex;

static void queueEvent(SimulatedEvent ev) {
    std::lock_guard<std::mutex> lock(g_eventMutex);
    g_eventQueue.push_back(ev);
}

// ─── Hook: CCMouseDispatcher — receive our synthetic events ─────────────────

class $modify(MyCCMouseDispatcher, CCMouseDispatcher) {
    struct Fields {
        float lastClickTime = 0.f;
    };
    
    bool dispatchScroll(float y, float x) {
        float sens = getSettingFloat("sensitivity", 1.0f);
        float scroll = y * sens;
        if (getSettingBool("invert-scroll", false)) scroll = -scroll;
        
        // Forward to the underlying dispatcher
        return CCMouseDispatcher::dispatchScroll(scroll, x * sens);
    }
};

// ─── Hook: PlayLayer — disable native touch when pointer is used ────────────

class $modify(MyPlayLayer, PlayLayer) {
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return false;
        return PlayLayer::ccTouchBegan(touch, event);
    }
    
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        PlayLayer::ccTouchMoved(touch, event);
    }
    
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        PlayLayer::ccTouchEnded(touch, event);
    }
};

// ─── Hook: MenuLayer ────────────────────────────────────────────────────────

class $modify(MyMenuLayer, MenuLayer) {
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return false;
        return MenuLayer::ccTouchBegan(touch, event);
    }
    
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        MenuLayer::ccTouchMoved(touch, event);
    }
    
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        MenuLayer::ccTouchEnded(touch, event);
    }
};

// ─── Hook: CCEGLView — intercept Android input events ───────────────────────

class $modify(MyCCEGLView, CCEGLView) {
    struct Fields {
        bool initialized = false;
    };
    
    // Called every frame from the main thread
    void processPointerEvents() {
        std::lock_guard<std::mutex> lock(g_pointerMutex);
        
        if (!g_hasPointerDevice) return;
        
        auto dir = CCDirector::get();
        auto winSize = dir->getWinSize();
        float sens = getSettingFloat("sensitivity", 1.0f);
        
        // Update cursor position
        if (g_pointer.hasMoved) {
            g_pointer.x += g_pointer.rawDx * sens;
            g_pointer.y += g_pointer.rawDy * sens;
            
            // Clamp to screen
            g_pointer.x = std::clamp(g_pointer.x, 0.f, winSize.width);
            g_pointer.y = std::clamp(g_pointer.y, 0.f, winSize.height);
            
            g_pointer.rawDx = 0.f;
            g_pointer.rawDy = 0.f;
            g_pointer.hasMoved = false;
        }
        
        // Update cursor sprite
        if (g_cursor && g_cursorVisible) {
            g_cursor->setPosition({g_pointer.x, g_pointer.y});
        }
        
        // Process scroll
        if (std::abs(g_pointer.scrollDelta) > 0.01f) {
            auto dispatcher = CCMouseDispatcher::get();
            if (dispatcher) {
                dispatcher->dispatchScroll(g_pointer.scrollDelta, 0.f);
            }
            g_pointer.scrollDelta = 0.f;
        }
    }
    
    // Called from the input thread to queue a mouse event
    static void onPointerMove(float dx, float dy) {
        std::lock_guard<std::mutex> lock(g_pointerMutex);
        g_pointer.hasMoved = true;
        g_pointer.rawDx += dx;
        g_pointer.rawDy += dy;
    }
    
    static void onPointerButton(int button, bool down) {
        // button: 0=left, 1=right, 2=middle
        float x, y;
        {
            std::lock_guard<std::mutex> lock(g_pointerMutex);
            x = g_pointer.x;
            y = g_pointer.y;
            if (button == 0) g_pointer.leftDown = down;
            else if (button == 1) g_pointer.rightDown = down;
            else if (button == 2) g_pointer.middleDown = down;
        }
        
        // Queue the event for main-thread dispatch
        SimulatedEvent ev;
        ev.type = down ? SimulatedEventType::MouseDown : SimulatedEventType::MouseUp;
        ev.x = x;
        ev.y = y;
        ev.button = button;
        ev.scrollY = 0;
        queueEvent(ev);
    }
    
    static void onPointerScroll(float delta) {
        std::lock_guard<std::mutex> lock(g_pointerMutex);
        g_pointer.scrollDelta += delta;
    }
    
    static void onPointerConnect() {
        g_hasPointerDevice = true;
        if (g_cursor) {
            g_cursor->setVisible(g_cursorVisible);
        }
    }
    
    static void onPointerDisconnect() {
        g_hasPointerDevice = false;
        if (g_cursor) {
            g_cursor->setVisible(false);
        }
    }
};

// ─── Hook: CCScheduler — per-frame update ───────────────────────────────────

class $modify(MyCCScheduler, CCScheduler) {
    void update(float dt) override {
        // Let original scheduler run
        CCScheduler::update(dt);
        
        // Process queued input events on main thread
        processQueuedEvents();
        
        // Process pointer state
        auto* view = static_cast<MyCCEGLView*>(CCEGLView::get());
        if (view) {
            view->processPointerEvents();
        }
    }
    
private:
    void processQueuedEvents() {
        std::vector<SimulatedEvent> events;
        {
            std::lock_guard<std::mutex> lock(g_eventMutex);
            events.swap(g_eventQueue);
        }
        
        for (auto& ev : events) {
            switch (ev.type) {
                case SimulatedEventType::MouseDown:
                case SimulatedEventType::MouseUp: {
                    // Simulate mouse clicks via CCMouseDispatcher
                    auto dispatcher = CCMouseDispatcher::get();
                    if (dispatcher) {
                        if (ev.type == SimulatedEventType::MouseDown) {
                            dispatcher->dispatchScroll(0, 0); // dummy to wake up
                        }
                    }
                    
                    // Forward to the CCTouch system using a synthetic touch
                    auto dir = CCDirector::get();
                    auto touch = CCTouch::touchWithDelegate(nullptr);
                    auto glView = CCEGLView::get();
                    if (glView) {
                        auto handler = glView->getMouseHandler();
                        if (handler) {
                            // Simulate the click using mouse dispatcher directly
                            if (ev.type == SimulatedEventType::MouseDown) {
                                // Use the dispatcher
                                dispatcher->dispatchScroll(0, 0);
                            }
                        }
                    }
                    break;
                }
                case SimulatedEventType::Scroll: {
                    auto dispatcher = CCMouseDispatcher::get();
                    if (dispatcher) {
                        dispatcher->dispatchScroll(ev.scrollY, 0.f);
                    }
                    break;
                }
                default:
                    break;
            }
        }
    }
};

// ─── Hook: EditorUI — right-click erase support ─────────────────────────────

class $modify(MyEditorUI, EditorUI) {
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice && g_pointer.rightDown) {
            // Right-click: simulate delete action
            this->onDeleteSelected(nullptr);
            return false;
        }
        if (g_hasPointerDevice) return false;
        return EditorUI::ccTouchBegan(touch, event);
    }
};

// ─── Mod entry point ────────────────────────────────────────────────────────

$execute {
    // Show cursor on first load
    g_cursorVisible = getSettingBool("show-cursor", true);
    
    // Listen for setting changes to update cursor
    listenForSettingChanges("cursor-size", [](double val) {
        if (g_cursor) {
            g_cursor->updateScale();
        }
    });
    
    listenForSettingChanges("show-cursor", [](bool val) {
        g_cursorVisible = val;
        if (g_cursor) {
            g_cursor->setVisible(val && g_hasPointerDevice);
        }
    });
    
    listenForSettingChanges("sensitivity", [](double) {
        // Sensitivity is read dynamically each frame
    });
    
    listenForSettingChanges("invert-scroll", [](bool) {
        // Invert is read dynamically each frame
    });
}

$on_mod(Loaded) {
    // Create cursor and add to the scene
    auto dir = CCDirector::get();
    auto scene = dir->getRunningScene();
    
    if (!g_cursor) {
        g_cursor = CursorNode::create();
        if (g_cursor) {
            g_cursor->setVisible(g_cursorVisible && g_hasPointerDevice);
            
            if (scene) {
                scene->addChild(g_cursor, 999999);
            } else {
                // Scene not ready yet — schedule addition
                dir->getScheduler()->schedule([dir](float) {
                    auto sc = dir->getRunningScene();
                    if (sc && g_cursor && !g_cursor->getParent()) {
                        sc->addChild(g_cursor, 999999);
                        return true; // unschedule
                    }
                    return false;
                }, 0.f, 0, 0.f, "add-cursor-schedule"_spr);
            }
        }
    }
    
    // Listen for scene changes to re-parent cursor
    dir->getEventDispatcher()->addCustomEventListener("onSceneEnter", [](CCObject*) {
        if (g_cursor && !g_cursor->getParent()) {
            auto sc = CCDirector::get()->getRunningScene();
            if (sc) {
                sc->addChild(g_cursor, 999999);
            }
        }
    });
    
    log::info("Mouse on Android mod loaded — connect a mouse or trackpad!");
}

// ─── Low-level Android input bridge ─────────────────────────────────────────
// This section provides the JNI bridge to capture Android pointer events.
// It relies on the Geode Android hook system to intercept AInputEvents.

#ifdef GEODE_IS_ANDROID

#include <jni.h>
#include <android/input.h>
#include <android/keycodes.h>
#include <Geode/modify/CCEGLView.hpp>

// JNI helper to register native methods for input capture
static JNIEnv* getJNIEnv() {
    auto vm = geode::jni::getVM();
    JNIEnv* env;
    if (vm->GetEnv(reinterpret_cast<void**>(&env), JNI_VERSION_1_6) != JNI_OK) {
        vm->AttachCurrentThread(&env, nullptr);
    }
    return env;
}

// This function is called from Java via JNI when a mouse event occurs
extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseMove(
    JNIEnv* env, jclass cls, jfloat dx, jfloat dy) {
    MyCCEGLView::onPointerMove(static_cast<float>(dx), static_cast<float>(dy));
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseButton(
    JNIEnv* env, jclass cls, jint button, jboolean down) {
    MyCCEGLView::onPointerButton(static_cast<int>(button), down == JNI_TRUE);
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseScroll(
    JNIEnv* env, jclass cls, jfloat delta) {
    MyCCEGLView::onPointerScroll(static_cast<float>(delta));
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerConnect(
    JNIEnv* env, jclass cls) {
    MyCCEGLView::onPointerConnect();
}

extern "C" JNIEXPORT void JNICALL
Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerDisconnect(
    JNIEnv* env, jclass cls) {
    MyCCEGLView::onPointerDisconnect();
}

// Register JNI native methods on load
$on_mod(Loaded) {
    auto env = getJNIEnv();
    jclass clazz = env->FindClass("com/geode/mouse_on_android/MouseBridge");
    if (!clazz) {
        log::warn("Could not find MouseBridge Java class — mouse events won't arrive");
        return;
    }
    
    JNINativeMethod methods[] = {
        {"nativeOnMouseMove",      "(FF)V", reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseMove)},
        {"nativeOnMouseButton",    "(IZ)V", reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseButton)},
        {"nativeOnMouseScroll",    "(F)V",  reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnMouseScroll)},
        {"nativeOnPointerConnect", "()V",   reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerConnect)},
        {"nativeOnPointerDisconnect","()V", reinterpret_cast<void*>(Java_com_geode_mouse_1on_1android_MouseBridge_nativeOnPointerDisconnect)},
    };
    
    if (env->RegisterNatives(clazz, methods, 5) < 0) {
        log::warn("Failed to register native methods for MouseBridge");
    } else {
        log::info("JNI bridge registered for mouse input");
    }
    
    env->DeleteLocalRef(clazz);
}

#endif // GEODE_IS_ANDROID
