#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

// ─── Forward declarations ─────────────────────────────────────────────

namespace {
    extern float g_cursorX;
    extern float g_cursorY;
    extern bool g_hasPointerDevice;
}

// ─── Hook: MenuLayer — suppress touch when mouse active ───────────────

class $modify(MyMenuLayerHook, MenuLayer) {
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return false;
        return MenuLayer::ccTouchBegan(touch, event);
    }
    
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        MenuLayer::ccTouchMoved(touch, event);
    }
    
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        MenuLayer::ccTouchEnded(touch, event);
    }
    
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        MenuLayer::ccTouchCancelled(touch, event);
    }
};
