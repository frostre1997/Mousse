#include <Geode/Geode.hpp>
#include <Geode/modify/CCScene.hpp>

using namespace geode::prelude;

// ─── Forward declarations ─────────────────────────────────────────────

namespace {
    class CursorNode;
    extern CursorNode* g_cursor;
    extern bool g_cursorVisible;
}

// ─── Cursor node implementation ───────────────────────────────────────

class CursorNode : public CCSprite {
protected:
    bool init() override {
        if (!CCSprite::init()) return false;
        
        auto contentSize = CCSize{24, 24};
        auto renderTexture = CCRenderTexture::create(
            static_cast<int>(contentSize.width),
            static_cast<int>(contentSize.height)
        );
        
        renderTexture->beginWithClear(0, 0, 0, 0);
        
        auto drawNode = CCDrawNode::create();
        // Outer ring (semi-transparent)
        drawNode->drawCircle(
            {contentSize.width / 2, contentSize.height / 2},
            10, 0, 360, false, 1, 1,
            {1, 1, 1, 0.4f}
        );
        // Inner dot (solid white)
        drawNode->drawDot(
            {contentSize.width / 2, contentSize.height / 2},
            4,
            {1, 1, 1, 1}
        );
        drawNode->visit();
        
        renderTexture->end();
        
        auto texture = renderTexture->getSprite()->getTexture();
        this->initWithTexture(texture);
        this->setAnchorPoint({0.5f, 0.5f});
        this->setZOrder(999999);
        this->setID("mouse-cursor"_spr);
        
        return true;
    }
    
public:
    static CursorNode* create() {
        auto ret = new CursorNode();
        if (ret && ret->init()) {
            ret->autorelease();
            return ret;
        }
        delete ret;
        return nullptr;
    }
    
    void updateSize(float scale) {
        this->setScale(scale);
    }
};

// ─── Global cursor instances ──────────────────────────────────────────

namespace {
    CursorNode* g_cursor = nullptr;
    bool g_cursorVisible = true;
}

// ─── Hook: CCScene — add cursor to new scenes ─────────────────────────

class $modify(MyCCSceneHook, CCScene) {
    bool init() override {
        if (!CCScene::init()) return false;
        
        // Add cursor if it exists and doesn't have a parent
        if (g_cursor && !g_cursor->getParent()) {
            this->addChild(g_cursor, 999999);
            g_cursor->setVisible(g_cursorVisible);
        }
        
        return true;
    }
};

// ─── Public interface for cursor control ──────────────────────────────

namespace cursor_api {
    void createCursor() {
        if (!g_cursor) {
            g_cursor = CursorNode::create();
            if (g_cursor) {
                g_cursor->setVisible(g_cursorVisible);
            }
        }
    }
    
    void setCursorVisible(bool visible) {
        g_cursorVisible = visible;
        if (g_cursor) {
            g_cursor->setVisible(visible);
        }
    }
    
    bool isCursorVisible() {
        return g_cursorVisible;
    }
    
    void setCursorPosition(float x, float y) {
        if (g_cursor) {
            g_cursor->setPosition({x, y});
        }
    }
    
    void setCursorScale(float scale) {
        if (g_cursor) {
            g_cursor->updateSize(scale);
        }
    }
}
