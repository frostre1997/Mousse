#include <Geode/Geode.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include <Geode/modify/LevelEditorLayer.hpp>

using namespace geode::prelude;

// ─── Forward declarations ─────────────────────────────────────────────

namespace {
    extern float g_cursorX;
    extern float g_cursorY;
    extern bool g_hasPointerDevice;
}

// ─── Hook: PlayLayer — suppress touch when mouse active ───────────────

class $modify(MyPlayLayerHook, PlayLayer) {
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return false;
        return PlayLayer::ccTouchBegan(touch, event);
    }
    
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        PlayLayer::ccTouchMoved(touch, event);
    }
    
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        PlayLayer::ccTouchEnded(touch, event);
    }
    
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        PlayLayer::ccTouchCancelled(touch, event);
    }
};

// ─── Hook: LevelEditorLayer — suppress touch when mouse active ────────

class $modify(MyLevelEditorLayerHook, LevelEditorLayer) {
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return false;
        return LevelEditorLayer::ccTouchBegan(touch, event);
    }
    
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        LevelEditorLayer::ccTouchMoved(touch, event);
    }
    
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        LevelEditorLayer::ccTouchEnded(touch, event);
    }
    
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        LevelEditorLayer::ccTouchCancelled(touch, event);
    }
};
