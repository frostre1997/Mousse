#include <Geode/Geode.hpp>
#include <Geode/modify/EditorUI.hpp>

using namespace geode::prelude;

// ─── Forward declarations ─────────────────────────────────────────────

namespace {
    extern float g_cursorX;
    extern float g_cursorY;
    extern bool g_hasPointerDevice;
    extern bool g_rightMouseDown;
}

// ─── Hook: EditorUI — right-click to delete ───────────────────────────

class $modify(MyEditorUIHook, EditorUI) {
    /// Override touch handling to support right-click delete
    bool ccTouchBegan(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice && g_rightMouseDown) {
            // Right-click detected — perform delete
            this->onDeleteSelected(nullptr);
            return false;
        }
        
        if (g_hasPointerDevice) {
            // Left click or unknown — suppress native touch
            return false;
        }
        
        return EditorUI::ccTouchBegan(touch, event);
    }
    
    /// Prevent touch-move interference when mouse is active
    void ccTouchMoved(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        EditorUI::ccTouchMoved(touch, event);
    }
    
    void ccTouchEnded(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        EditorUI::ccTouchEnded(touch, event);
    }
    
    void ccTouchCancelled(CCTouch* touch, CCEvent* event) override {
        if (g_hasPointerDevice) return;
        EditorUI::ccTouchCancelled(touch, event);
    }
};
