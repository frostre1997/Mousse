#include <Geode/Geode.hpp>
#include <Geode/modify/CCEGLView.hpp>

using namespace geode::prelude;

// ─── Globals set from main.cpp ────────────────────────────────────────
// These are forward-declared here to avoid circular deps.

namespace {
    extern float g_cursorX;
    extern float g_cursorY;
    extern bool g_hasPointerDevice;
}

// ─── Hook into CCEGLView to intercept pointer input ───────────────────

class $modify(MyCCEGLViewHook, CCEGLView) {
    /// Intercept touch events — suppress native touch when mouse is active
    bool onTouchEvent(CCTouchEvent* event) override {
        if (g_hasPointerDevice) {
            // Suppress touch events when a mouse is connected
            // to prevent double-input (touch + synthetic mouse)
            return true;
        }
        return CCEGLView::onTouchEvent(event);
    }
};
